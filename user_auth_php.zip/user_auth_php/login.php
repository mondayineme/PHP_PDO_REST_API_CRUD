<?php

require_once "config.php";

$response = array();

// User login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the entered username and password match a user in the database
    $stmt = $db->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Return success response
        $response = ['status' => 'success', 'message' => 'Login successful!'];
        echo json_encode($response);
    } else {
        // Invalid username or password
        $response = ['status' => 'error', 'message' => 'Invalid username or password!'];
        echo json_encode($response);
    }
}else{
    // Invalid API request
    $response = ['status' => 'error', 'message' => 'Invalid API request'];
    echo json_encode($response);
}

?>
