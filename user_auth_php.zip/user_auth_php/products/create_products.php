<?php
require_once "config.php";

$response = array();

// Create a new user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    $query = $db->prepare('INSERT INTO products (name, description, price, category) VALUES (:name, :description, :price, :category)');
    $query->bindParam(':name', $name);
    $query->bindParam(':description', $description);
    $query->bindParam(':price', $price);
    $query->bindParam(':category', $category);
    $result = $query->execute();

    if($result){
        $response = ['status' => true, 'message' => 'Product Added successful!'];
        echo json_encode($response);
    }
}