<?php
require_once "config.php";

// Set the response content type to JSON
header("Content-Type: application/json");

// Include the database connection file
require_once 'your_database_connection_file.php';

// Delete a user by ID
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['id'])) {

    $id = $_GET['id'];

    $query = $db->prepare('DELETE FROM products WHERE id = :id');
    $query->bindParam(':id', $id);
    $query->execute();

    echo json_encode(['message' => 'User deleted successfully']);
}