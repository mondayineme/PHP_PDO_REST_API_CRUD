<?php
require_once "config.php";

// Set the response content type to JSON
header("Content-Type: application/json");

// Include the database connection file
require_once 'your_database_connection_file.php';

// Retrieve a single user by ID
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = $db->prepare('SELECT * FROM products WHERE id = :id');
    $query->bindParam(':id', $id);
    $query->execute();
    $user = $query->fetch(PDO::FETCH_ASSOC);
    echo json_encode($user);
}
