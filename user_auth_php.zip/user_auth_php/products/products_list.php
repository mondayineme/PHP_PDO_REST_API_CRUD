<?php
require_once "config.php";

// Set the response content type to JSON
header("Content-Type: application/json");

// Include the database connection file
require_once 'your_database_connection_file.php';

// Retrieve all users
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = $db->query('SELECT * FROM products');
    $users = $query->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($users);
}
