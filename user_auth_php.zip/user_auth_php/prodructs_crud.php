<?php
// Set the response content type to JSON
header("Content-Type: application/json");

// Include the database connection file
require_once 'your_database_connection_file.php';

// Retrieve all users
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = $db->query('SELECT * FROM users');
    $users = $query->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($users);
}

// Retrieve a single user by ID
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = $db->prepare('SELECT * FROM users WHERE id = :id');
    $query->bindParam(':id', $id);
    $query->execute();
    $user = $query->fetch(PDO::FETCH_ASSOC);
    echo json_encode($user);
}

// Create a new user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];

    $query = $db->prepare('INSERT INTO users (name, email, age) VALUES (:name, :email, :age)');
    $query->bindParam(':name', $name);
    $query->bindParam(':email', $email);
    $query->bindParam(':age', $age);
    $query->execute();

    echo json_encode(['message' => 'User created successfully']);
}

// Update a user by ID
if ($_SERVER['REQUEST_METHOD'] === 'PUT' && isset($_GET['id'])) {
    $id = $_GET['id'];
    parse_str(file_get_contents("php://input"), $putParams);
    $name = $putParams['name'];
    $email = $putParams['email'];
    $age = $putParams['age'];

    $query = $db->prepare('UPDATE users SET name = :name, email = :email, age = :age WHERE id = :id');
    $query->bindParam(':id', $id);
    $query->bindParam(':name', $name);
    $query->bindParam(':email', $email);
    $query->bindParam(':age', $age);
    $query->execute();

    echo json_encode(['message' => 'User updated successfully']);
}

// Delete a user by ID
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = $db->prepare('DELETE FROM users WHERE id = :id');
    $query->bindParam(':id', $id);
    $query->execute();

    echo json_encode(['message' => 'User deleted successfully']);
}
?>
