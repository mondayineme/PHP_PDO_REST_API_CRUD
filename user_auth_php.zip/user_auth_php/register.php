<?php
require_once "config.php";

$response = array();

// Register a new user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    // $password = $_POST['password'];

    // Check if username is already taken
    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        // Return response
        $response = ['status' => 'error', 'message' => 'Username already exists'];
        echo json_encode($response);
    } else {
        // Insert new user into the database
        $stmt = $db->prepare("INSERT INTO users (name, username, password) VALUES (:name, :username, :password)");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->execute();

        // Return success response
        $response = ['status' => 'success', 'message' => 'Registration successful!'];
        echo json_encode($response);
    }
}else{
    // Invalid API request
    $response = ['status' => 'error', 'message' => 'Invalid API request'];
    echo json_encode($response);
}

?>
