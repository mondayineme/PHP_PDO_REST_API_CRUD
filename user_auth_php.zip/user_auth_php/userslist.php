<?php

require "config.php";

$response = array();

$query = "SELECT id, username, name FROM users";
$stmt = $db->prepare($query);
$stmt->execute();

$response["details"] = array();
    
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    $data = array();
    $data["id"]=$row["id"];
    $data["name"]=$row["name"];
    $data["username"]=$row["username"];
    array_push($response["details"], $data);
}

$response["success"] = true;
$response["message"] = "Successfully Displayed";
echo json_encode($response);